import React from 'react'

export default function HomeIcon() {
  return (
    <div>HomeIcon</div>
  )
}