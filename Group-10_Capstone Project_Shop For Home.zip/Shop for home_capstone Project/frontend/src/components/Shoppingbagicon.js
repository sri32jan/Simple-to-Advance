import React from 'react'

export default function ShopingBagIcon() {
  return (
    <div>ShopingBagIcon</div>
  )
}
