import React from 'react'
import {Link} from 'react-router-dom'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Carousel from 'react-bootstrap/Carousel';
import '../style/style.css';

export default function Home() {
  return (
    <Box sx={{padding: "12px", display: "flex", flexWrap: "wrap", justifyContent: "space-around", alignItems: "center", width: "100%", minHeight: '100vh'}} >
      <Box>
        <Typography variant="h4" >UNIQUE AND<br /> AFFORDABLE</Typography>
        <Typography variant='body1' >We offer our clients a unique variety of<br/> affordable home decor solutions!!</Typography>
        <Link style={{textDecoration: "none"}} to="/products">
        <Button sx={{margin: "16px 0px"}} variant="contained" >Shop Now</Button>
        </Link>
      </Box>
      {/* <img width={850} src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png" alt="home" /> */}
      <div>
      <Carousel fade>
  <Carousel.Item>
    <img
      className ="d-block w-100 Imagestyling"
      src="https://assets.ccbp.in/frontend/react-js/nxt-trendz-login-img.png"
      alt="First slide"
    />
    <Carousel.Caption>
      
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100 Imagestyling"
      src="https://img.freepik.com/free-photo/happy-asian-pretty-girl-holding-shopping-bags-while-using-smartphone_35721-211.jpg"
      alt="Second slide"
    />

    <Carousel.Caption>
      
    </Carousel.Caption>
  </Carousel.Item>
  <Carousel.Item>
    <img
      className="d-block w-100 Imagestyling"
      src="https://i.pinimg.com/originals/28/60/52/286052a4fd45d9f29d412c9cbda93bd3.jpg"
      alt="Third slide"
    />

    <Carousel.Caption>
      
    </Carousel.Caption>
  </Carousel.Item>
</Carousel>
    </div>
    </Box>
  )
}
