import React, { useEffect, useState } from 'react'
import "./Dashb.css"
import { isLoggedIn, isAdmin, doLogout,getUser} from '../service/Auth';
import { getProducts} from '../service/Product';
import { Doughnut } from "react-chartjs-2";
import '../style/style.css'
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);
function Dashboard() {
  // const lineState = {
  //   labels: ["Initial Amount", "Amount Earned"],
  //   datasets: [
  //     {
  //       label: "TOTAL AMOUNT",
  //       backgroundColor: ["tomato"],
  //       hoverBackgroundColor: ["rgb(197,72,49)"],
  //       data: [0, totalAmount],
  //     },
  //   ],
  // };

  // let outStock = 0;
  // Products.forEach((product) => {
  //   if (product.stock <=10) {
  //     outStock += 1;
  //   }
  // });

  const doughnutState = {
    labels: ["Out of Stock", "InStock"],
    datasets: [
      {
        backgroundColor: ["#00A6B4", "#6800B4"],
        hoverBackgroundColor: ["#435000", "#35014F"],
        data: [2, 10],
      },
    ],
  };
    const [totalProduct, settotalProduct] = useState([])
  const [outOfStock, setoutOfStock] = useState(0)
  const [totalAmount, settotalAmount] = useState(0)

  
  useEffect(() => {
    getProducts()
      .then(res => {
        if (res.data.err === 0) {
          settotalProduct(res.data.prodata)
          const productData=res.data.prodata;
          for (let index = 0; index < productData.length; index++) {
            if(productData[index].availableItems<=0) setoutOfStock(outOfStock+1);
            settotalAmount(totalAmount+productData[index].price)
          }
        }
      })
  }, [])
  return (
    <div>
         <h1 class="heading-name">Dashboard</h1>
    <div class="col-div-3">
        <div class="box">
            <center>
            <p>{totalProduct.length}<br/><span>Products</span></p>
            <i class="fa fa-users box-icon"></i>
            </center>
        </div>
    </div>
    <div class="col-div-3">
        <div class="box">
            <center>
            <p>1<br/><span>Orders</span> <br/></p>
            
            <i class="fa fa-list box-icon"></i>
            </center>
        </div>
    </div>
    <div class="col-div-3">
        <div class="box">
            <center>
            <p>2<br/><span>Users</span></p>
            <i class="fa fa-shopping-bag box-icon"></i>
            </center>
        </div>
    </div>
    <div class="col-div-3">
        <div class="box">
            <center>
            <p>{outOfStock}<br/><span>Out of Stock</span></p>
            <i class="fa fa-tasks box-icon"></i>
            </center>
        </div>
    </div>
    <div class="clearfix"></div>
    <br/><br/>
    <div class="col-div-12 padding-css">
        <div class="box">
            <center>
            <p>{totalAmount}Rs<br/><span>Total Amount</span></p>
            <i class="fa fa-tasks box-icon"></i>
            </center>
        </div>
    </div>
    {/* <div className="lineChart">
      <Line data={lineState} />
    </div> */}
                <div className="doughnutChart">
                  <Doughnut data={doughnutState} />
                </div>
                {/* <div className="lineChart">
      <Line data={lineState} />
    </div> */}
    </div>
  )
}

export default Dashboard