import React from 'react'

export default function FavoriteIcon() {
  return (
    <div>FavoriteIcon</div>
  )
}