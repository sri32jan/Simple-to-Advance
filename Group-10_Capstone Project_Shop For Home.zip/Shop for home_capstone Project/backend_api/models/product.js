const mongoose = require("mongoose");

const Product = mongoose.model(
  "product",
  new mongoose.Schema({
    name: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    description: {
      type: String,
    },
    manufacturer: {
      type: String,
    },
    Stock: {
      type: Number,
      required: true,
    },
    images: {
      public_id:{
        type: String,
        required:true
      },
      url:{
        type: String,
        required:true
      }
    },
  }, { timestamps: true })
);

module.exports = { Product };
